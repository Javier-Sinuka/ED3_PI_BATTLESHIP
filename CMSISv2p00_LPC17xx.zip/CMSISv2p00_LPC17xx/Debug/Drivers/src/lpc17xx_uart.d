Drivers/src/lpc17xx_uart.o Drivers/src/lpc17xx_uart.d: \
 ../Drivers/src/lpc17xx_uart.c
