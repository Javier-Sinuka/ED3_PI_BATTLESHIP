Drivers/src/lpc17xx_i2s.o Drivers/src/lpc17xx_i2s.d: \
 ../Drivers/src/lpc17xx_i2s.c \
 G:\Otros\ ordenadores\Mi\ PC\Materias\Digitales\ 3\IDE\ -\ Workspace\CMSISv2p00_LPC17xx\Drivers\inc/lpc17xx_i2s.h \
 ../inc/LPC17xx.h ../inc/core_cm3.h ../inc/core_cmInstr.h \
 ../inc/core_cmFunc.h ../inc/system_LPC17xx.h \
 G:\Otros\ ordenadores\Mi\ PC\Materias\Digitales\ 3\IDE\ -\ Workspace\CMSISv2p00_LPC17xx\Drivers\inc/lpc_types.h \
 G:\Otros\ ordenadores\Mi\ PC\Materias\Digitales\ 3\IDE\ -\ Workspace\CMSISv2p00_LPC17xx\Drivers\inc/lpc17xx_clkpwr.h \
 ../inc/lpc17xx.h \
 G:\Otros\ ordenadores\Mi\ PC\Materias\Digitales\ 3\IDE\ -\ Workspace\CMSISv2p00_LPC17xx\Drivers\inc/lpc17xx_libcfg_default.h
G:\Otros\ ordenadores\Mi\ PC\Materias\Digitales\ 3\IDE\ -\ Workspace\CMSISv2p00_LPC17xx\Drivers\inc/lpc17xx_i2s.h:
../inc/LPC17xx.h:
../inc/core_cm3.h:
../inc/core_cmInstr.h:
../inc/core_cmFunc.h:
../inc/system_LPC17xx.h:
G:\Otros\ ordenadores\Mi\ PC\Materias\Digitales\ 3\IDE\ -\ Workspace\CMSISv2p00_LPC17xx\Drivers\inc/lpc_types.h:
G:\Otros\ ordenadores\Mi\ PC\Materias\Digitales\ 3\IDE\ -\ Workspace\CMSISv2p00_LPC17xx\Drivers\inc/lpc17xx_clkpwr.h:
../inc/lpc17xx.h:
G:\Otros\ ordenadores\Mi\ PC\Materias\Digitales\ 3\IDE\ -\ Workspace\CMSISv2p00_LPC17xx\Drivers\inc/lpc17xx_libcfg_default.h:
