Drivers/src/lpc17xx_gpdma.o Drivers/src/lpc17xx_gpdma.d: \
 ../Drivers/src/lpc17xx_gpdma.c \
 G:\Otros\ ordenadores\Mi\ PC\Materias\Digitales\ 3\IDE\ -\ Workspace\CMSISv2p00_LPC17xx\Drivers\inc/lpc17xx_gpdma.h \
 ../inc/LPC17xx.h ../inc/core_cm3.h ../inc/core_cmInstr.h \
 ../inc/core_cmFunc.h ../inc/system_LPC17xx.h \
 G:\Otros\ ordenadores\Mi\ PC\Materias\Digitales\ 3\IDE\ -\ Workspace\CMSISv2p00_LPC17xx\Drivers\inc/lpc_types.h \
 G:\Otros\ ordenadores\Mi\ PC\Materias\Digitales\ 3\IDE\ -\ Workspace\CMSISv2p00_LPC17xx\Drivers\inc/lpc17xx_clkpwr.h \
 ../inc/lpc17xx.h \
 G:\Otros\ ordenadores\Mi\ PC\Materias\Digitales\ 3\IDE\ -\ Workspace\CMSISv2p00_LPC17xx\Drivers\inc/lpc17xx_libcfg_default.h
G:\Otros\ ordenadores\Mi\ PC\Materias\Digitales\ 3\IDE\ -\ Workspace\CMSISv2p00_LPC17xx\Drivers\inc/lpc17xx_gpdma.h:
../inc/LPC17xx.h:
../inc/core_cm3.h:
../inc/core_cmInstr.h:
../inc/core_cmFunc.h:
../inc/system_LPC17xx.h:
G:\Otros\ ordenadores\Mi\ PC\Materias\Digitales\ 3\IDE\ -\ Workspace\CMSISv2p00_LPC17xx\Drivers\inc/lpc_types.h:
G:\Otros\ ordenadores\Mi\ PC\Materias\Digitales\ 3\IDE\ -\ Workspace\CMSISv2p00_LPC17xx\Drivers\inc/lpc17xx_clkpwr.h:
../inc/lpc17xx.h:
G:\Otros\ ordenadores\Mi\ PC\Materias\Digitales\ 3\IDE\ -\ Workspace\CMSISv2p00_LPC17xx\Drivers\inc/lpc17xx_libcfg_default.h:
