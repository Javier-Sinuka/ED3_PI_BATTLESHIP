Drivers/src/debug_frmwrk.o Drivers/src/debug_frmwrk.d: \
 ../Drivers/src/debug_frmwrk.c
